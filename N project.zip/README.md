# How to run
1. Download the project
2. Open index.html